=====
Logger
=====

Logger is a simple Django app to capture insights from the way a user interacts with a django site. 
Detailed documentation is in the "docs" directory.

Quick start
-----------

1. Add "logger" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'logger',
    ]

2. Include the polls URLconf in your project urls.py like this::

    path('logger/', include('logger.urls')),

3. Run `python manage.py migrate` to create the logger models.

4. Start the development server and visit http://127.0.0.1:8000/admin/
   to create a poll (you'll need the Admin app enabled).

5. Visit http://127.0.0.1:8000/logger/ to participate in the poll.